<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>App</name>
    <message>
        <location filename="../stacer/app.cpp" line="80"/>
        <source>Dashboard</source>
        <translation>儀表板</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="85"/>
        <source>System Cleaner</source>
        <translation>系統清理</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="90"/>
        <source>System Startup Apps</source>
        <translation>系統開機啟動項目</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="95"/>
        <source>System Services</source>
        <translation>系統服務</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="100"/>
        <source>Uninstaller</source>
        <translation>解除安裝</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="105"/>
        <source>Resources</source>
        <translation>系統資源</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="110"/>
        <source>Processes</source>
        <translation>處理程序</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="115"/>
        <source>Settings</source>
        <translation>設定</translation>
    </message>
</context>
<context>
    <name>DashboardPage</name>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="153"/>
        <source>SYSTEM INFO</source>
        <translation>系統資訊</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="240"/>
        <source>There are update currently available.</source>
        <translation>目前有可用更新</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="253"/>
        <source>Download</source>
        <translation>下載</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="18"/>
        <source>CPU</source>
        <translation>CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="19"/>
        <source>MEMORY</source>
        <translation>記憶體</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="20"/>
        <source>DISK</source>
        <translation>磁碟</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="21"/>
        <source>DOWNLOAD</source>
        <translation>下載</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="22"/>
        <source>UPLOAD</source>
        <translation>上傳</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="107"/>
        <source>Hostname: %1</source>
        <translation>主機名稱: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="108"/>
        <source>Platform: %1</source>
        <translation>平台: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="109"/>
        <source>Distribution: %1</source>
        <translation>發行版: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="110"/>
        <source>Kernel Release: %1</source>
        <translation>Kernel 版本: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="111"/>
        <source>CPU Model: %1</source>
        <translation>CPU 型號: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="112"/>
        <source>CPU Speed: %1</source>
        <translation>CPU 時脈: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="113"/>
        <source>CPU Core: %1</source>
        <translation>CPU 核心: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="182"/>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="186"/>
        <source>Total: %1</source>
        <translation>總計: %1</translation>
    </message>
</context>
<context>
    <name>ProcessesPage</name>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="55"/>
        <source>Processes</source>
        <translation>處理程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="68"/>
        <source>All Processes</source>
        <translation>所有處理程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="88"/>
        <source>Search...</source>
        <translation>搜尋...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="206"/>
        <source>End Process</source>
        <translation>結束處理程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>User</source>
        <translation>使用者</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Resident Memory</source>
        <translation>常駐記憶體</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>%Memory</source>
        <translation>%記憶體</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Virtual Memory</source>
        <translation>虛擬記憶體</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Start Time</source>
        <translation>開始時間</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>State</source>
        <translation>狀態</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Group</source>
        <translation>群組</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Nice</source>
        <translation>優先權</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>CPU Time</source>
        <translation>CPU 時間</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Session</source>
        <translation>工作階段</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Seat</source>
        <translation>座位</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Process</source>
        <translation>處理程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="104"/>
        <source>Processes (%1)</source>
        <translation>處理程序 (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="198"/>
        <source>Refresh (%1)</source>
        <translation>更新 (每 %1 秒)</translation>
    </message>
</context>
<context>
    <name>ResourcesPage</name>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="26"/>
        <source>CPU History</source>
        <translation>CPU 使用量記錄</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="29"/>
        <source>Memory History</source>
        <translation>記憶體使用量記錄</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="32"/>
        <source>Network History</source>
        <translation>網路使用量記錄</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="76"/>
        <source>Download %1/s Total: %2</source>
        <translation>下載 %1/s 總計: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="81"/>
        <source>Upload %1/s  Total: %2</source>
        <translation>上傳 %1/s 總計: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="122"/>
        <source>Swap %1 (%2%) %3</source>
        <translation>交換區 %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="131"/>
        <source>Memory %1 (%2%) %3</source>
        <translation>記憶體 %1 (%2%) %3</translation>
    </message>
</context>
<context>
    <name>ServicesPage</name>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="79"/>
        <source>System Services</source>
        <translation>系統服務</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="123"/>
        <source>Startup at boot ?</source>
        <translation>開機後自動啟動？</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="176"/>
        <source>Running Now ?</source>
        <translation>立即執行？</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="246"/>
        <source>Not Found System Service</source>
        <translation>沒有找到系統服務</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="50"/>
        <source>System Services (%1)</source>
        <translation>系統服務 (%1)</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="54"/>
        <source>Language</source>
        <translation>語言</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="71"/>
        <source>Theme</source>
        <translation>主題</translation>
    </message>
</context>
<context>
    <name>StartupApp</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="23"/>
        <source>Delete</source>
        <translation>刪除</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="24"/>
        <source>Edit</source>
        <translation>編輯</translation>
    </message>
</context>
<context>
    <name>StartupAppEdit</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="20"/>
        <source>Startup App</source>
        <translation>系統開機啟動項目</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="50"/>
        <source>Save</source>
        <translation>儲存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="60"/>
        <source>Fields cannot be left blank. </source>
        <translation>欄位不能為空</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="67"/>
        <source>App Comment</source>
        <translation>註解</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="74"/>
        <source>App Name</source>
        <translation>名稱</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="81"/>
        <source>Command</source>
        <translation>指令</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="88"/>
        <source>Application</source>
        <translation>應用程式</translation>
    </message>
</context>
<context>
    <name>StartupAppsPage</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="192"/>
        <source>Not Found Startup Apps</source>
        <translation>沒有找到系統開機啟動項目</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="112"/>
        <source>System Startup Applications</source>
        <translation>系統開機啟動項目</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="95"/>
        <source>Add Startup App</source>
        <translation>加入系統開機啟動項目</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.cpp" line="79"/>
        <source>System Startup Applications (%1)</source>
        <translation>系統開機啟動項目 (%1)</translation>
    </message>
</context>
<context>
    <name>SystemCleanerPage</name>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="63"/>
        <source>Crash Reports</source>
        <translation>當機報告</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="168"/>
        <source>Application Logs</source>
        <translation>應用程式日誌</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="206"/>
        <source>Application Caches</source>
        <translation>應用程式快取</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="327"/>
        <source>Trash</source>
        <translation>垃圾桶</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="365"/>
        <source>Package Caches</source>
        <translation>套件快取</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="473"/>
        <source> Back</source>
        <translation> 返回</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>File Name</source>
        <translation>檔案名稱</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="285"/>
        <source>%1 size files cleaned.</source>
        <translation>已清除 %1 的空間</translation>
    </message>
</context>
<context>
    <name>UninstallerPage</name>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="228"/>
        <source>System Installed Packages</source>
        <translation>系統已安裝的套件</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="271"/>
        <source>Search...</source>
        <translation>搜尋...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="178"/>
        <source>Not Found Installed Packages</source>
        <translation>未發現已安裝的套件</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="132"/>
        <source>Uninstall Selected</source>
        <translation>解除安裝選中的項目</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstaller_page.cpp" line="65"/>
        <source>System Installed Packages (%1)</source>
        <translation>系統已安裝的套件 (%1)</translation>
    </message>
</context>
</TS>
