<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>App</name>
    <message>
        <location filename="../stacer/app.cpp" line="80"/>
        <source>Dashboard</source>
        <translation>Panel de instrumentos</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="85"/>
        <source>System Cleaner</source>
        <translation>Limpiador del Sistema</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="90"/>
        <source>System Startup Apps</source>
        <translation>Aplicaciones en el inicio del sistema</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="95"/>
        <source>System Services</source>
        <translation>Servicios del Sistema</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="100"/>
        <source>Uninstaller</source>
        <translation>Paquetes instalado en el sistema</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="105"/>
        <source>Resources</source>
        <translation>Recursos</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="110"/>
        <source>Processes</source>
        <translation>Procesos</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="115"/>
        <source>Settings</source>
        <translation>Opciones</translation>
    </message>
</context>
<context>
    <name>DashboardPage</name>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="153"/>
        <source>SYSTEM INFO</source>
        <translation>INFORMACIÓN DEL SISTEMA</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="240"/>
        <source>There are update currently available.</source>
        <translation>Actualmente hay actualizaciones disponibles.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="253"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="18"/>
        <source>CPU</source>
        <translation>CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="19"/>
        <source>MEMORY</source>
        <translation>MEMORIA</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="20"/>
        <source>DISK</source>
        <translation>DISCO</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="21"/>
        <source>DOWNLOAD</source>
        <translation>DESCARGAR</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="22"/>
        <source>UPLOAD</source>
        <translation>ENVÍOS</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="107"/>
        <source>Hostname: %1</source>
        <translation>Nombre de host: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="108"/>
        <source>Platform: %1</source>
        <translation>Plataforma: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="109"/>
        <source>Distribution: %1</source>
        <translation>Distribución: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="110"/>
        <source>Kernel Release: %1</source>
        <translation>Versión del kernel: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="111"/>
        <source>CPU Model: %1</source>
        <translation>Modelo de CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="112"/>
        <source>CPU Speed: %1</source>
        <translation>Velocidad de la CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="113"/>
        <source>CPU Core: %1</source>
        <translation>Núcleo de la CPU:%1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="182"/>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="186"/>
        <source>Total: %1</source>
        <translation>Total: %1</translation>
    </message>
</context>
<context>
    <name>ProcessesPage</name>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="55"/>
        <source>Processes</source>
        <translation>Procesos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="68"/>
        <source>All Processes</source>
        <translation>Todos los Procesos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="88"/>
        <source>Search...</source>
        <translation>Buscar...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="206"/>
        <source>End Process</source>
        <translation>Proceso Final</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Resident Memory</source>
        <translation>Memoria Residente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>%Memory</source>
        <translation>%Memoria</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Virtual Memory</source>
        <translation>Memoria virtual</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Start Time</source>
        <translation>Hora de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Group</source>
        <translation>Grupo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Nice</source>
        <translation>Bonito</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>CPU Time</source>
        <translation>Tiempo de CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Session</source>
        <translation>Sesión</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Seat</source>
        <translation>Asiento</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Process</source>
        <translation>Proceso</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="104"/>
        <source>Processes (%1)</source>
        <translation>Procesos (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="198"/>
        <source>Refresh (%1)</source>
        <translation>Refresco (%1)</translation>
    </message>
</context>
<context>
    <name>ResourcesPage</name>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="26"/>
        <source>CPU History</source>
        <translation>Actividades Cpu</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="29"/>
        <source>Memory History</source>
        <translation>Actividades Mémoire</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="32"/>
        <source>Network History</source>
        <translation>Actividades Internet</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="76"/>
        <source>Download %1/s Total: %2</source>
        <translation>Descargar %1/s Total: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="81"/>
        <source>Upload %1/s  Total: %2</source>
        <translation>Subida %1 /s Total: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="122"/>
        <source>Swap %1 (%2%) %3</source>
        <translation>Intercambio %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="131"/>
        <source>Memory %1 (%2%) %3</source>
        <translation>Memoria %1 (%2%) %3</translation>
    </message>
</context>
<context>
    <name>ServicesPage</name>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="79"/>
        <source>System Services</source>
        <translation>Servicios del Sistema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="123"/>
        <source>Startup at boot ?</source>
        <translation>Inicio en el arranque ?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="176"/>
        <source>Running Now ?</source>
        <translation>Corriendo Ahora ?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="246"/>
        <source>Not Found System Service</source>
        <translation>Servicio del Sistema No Encontrado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="50"/>
        <source>System Services (%1)</source>
        <translation>Servicios del Sistema (%1)</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="54"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="71"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
</context>
<context>
    <name>StartupApp</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="23"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="24"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
</context>
<context>
    <name>StartupAppEdit</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="20"/>
        <source>Startup App</source>
        <translation>Aplicación de Inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="50"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="60"/>
        <source>Fields cannot be left blank. </source>
        <translation>Los campos no se pueden dejar en blanco. </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="67"/>
        <source>App Comment</source>
        <translation>Comentario de la Aplicación</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="74"/>
        <source>App Name</source>
        <translation>Nombre de la Aplicación</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="81"/>
        <source>Command</source>
        <translation>Mando</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="88"/>
        <source>Application</source>
        <translation>Aplicación</translation>
    </message>
</context>
<context>
    <name>StartupAppsPage</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="192"/>
        <source>Not Found Startup Apps</source>
        <translation>Aplicaciones de Inicio No Encontradas</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="112"/>
        <source>System Startup Applications</source>
        <translation>Aplicaciones de Inicio del Sistema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="95"/>
        <source>Add Startup App</source>
        <translation>Añadir Aplicación de Inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.cpp" line="79"/>
        <source>System Startup Applications (%1)</source>
        <translation>Aplicaciones de Inicio del Sistema (%1)</translation>
    </message>
</context>
<context>
    <name>SystemCleanerPage</name>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="63"/>
        <source>Crash Reports</source>
        <translation>Informes de fallos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="168"/>
        <source>Application Logs</source>
        <translation>Registros de Aplicaciones</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="206"/>
        <source>Application Caches</source>
        <translation>Aplicaciones en Caché</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="327"/>
        <source>Trash</source>
        <translation>Basura</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="365"/>
        <source>Package Caches</source>
        <translation>Paquete de Cachés</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="473"/>
        <source> Back</source>
        <translation> Espalda</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>File Name</source>
        <translation>Nombre del Archivo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="285"/>
        <source>%1 size files cleaned.</source>
        <translation>%1 archivos de tamaño limpiado.</translation>
    </message>
</context>
<context>
    <name>UninstallerPage</name>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="228"/>
        <source>System Installed Packages</source>
        <translation>Paquetes Instalados del Sistema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="271"/>
        <source>Search...</source>
        <translation>Buscar...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="178"/>
        <source>Not Found Installed Packages</source>
        <translation>Paquetes Instalados no Encontrados</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="132"/>
        <source>Uninstall Selected</source>
        <translation>Desinstalar Seleccionados</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstaller_page.cpp" line="65"/>
        <source>System Installed Packages (%1)</source>
        <translation>Paquetes Instalados del Sistema (%1)</translation>
    </message>
</context>
</TS>
