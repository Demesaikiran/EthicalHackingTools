<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk_UA">
<context>
    <name>App</name>
    <message>
        <location filename="../stacer/app.cpp" line="80"/>
        <source>Dashboard</source>
        <translation>Огляд</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="85"/>
        <source>System Cleaner</source>
        <translation>Очищення системи</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="90"/>
        <source>System Startup Apps</source>
        <translation>Програми які автоматично запускаються</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="95"/>
        <source>System Services</source>
        <translation>Системні служби</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="100"/>
        <source>Uninstaller</source>
        <translation>Видалення пакетів</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="105"/>
        <source>Resources</source>
        <translation>Ресурси</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="110"/>
        <source>Processes</source>
        <translation>Процеси</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="115"/>
        <source>Settings</source>
        <translation>Налаштування</translation>
    </message>
</context>
<context>
    <name>DashboardPage</name>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="153"/>
        <source>SYSTEM INFO</source>
        <translation>СИСТЕМНА ІНФОРМАЦІЯ</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="240"/>
        <source>There are update currently available.</source>
        <translation>Доступно оновлення.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="253"/>
        <source>Download</source>
        <translation>Завантажити</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="18"/>
        <source>CPU</source>
        <translation>ЦП</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="19"/>
        <source>MEMORY</source>
        <translation>ПАМ'ЯТЬ</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="20"/>
        <source>DISK</source>
        <translation>ДИСК</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="21"/>
        <source>DOWNLOAD</source>
        <translation>ОТРИМАНО</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="22"/>
        <source>UPLOAD</source>
        <translation>НАДІСЛАНО</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="107"/>
        <source>Hostname: %1</source>
        <translation>Ім'я комп'ютера: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="108"/>
        <source>Platform: %1</source>
        <translation>Платформа: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="109"/>
        <source>Distribution: %1</source>
        <translation>Дистрибутив: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="110"/>
        <source>Kernel Release: %1</source>
        <translation>Версія ядра: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="111"/>
        <source>CPU Model: %1</source>
        <translation>Модель ЦП: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="112"/>
        <source>CPU Speed: %1</source>
        <translation>Частота ЦП: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="113"/>
        <source>CPU Core: %1</source>
        <translation>Ядра ЦП: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="186"/>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="190"/>
        <source>Total: %1</source>
        <translation>Всього: %1</translation>
    </message>
</context>
<context>
    <name>ProcessesPage</name>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="55"/>
        <source>Processes</source>
        <translation>Процеси</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="68"/>
        <source>All Processes</source>
        <translation>Всі процеси</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="88"/>
        <source>Search...</source>
        <translation>Пошук...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="206"/>
        <source>End Process</source>
        <translation>Завершити процес</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Resident Memory</source>
        <translation>Резидентна пам'ять</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>%Memory</source>
        <translation>%Пам'ять</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Virtual Memory</source>
        <translation>Віртуальна пам'ять</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>User</source>
        <translation>Користувач</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Start Time</source>
        <translation>Запущено</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>State</source>
        <translation>Стан</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Group</source>
        <translation>Група</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Nice</source>
        <translation>Пріоритет</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>CPU Time</source>
        <translation>Час ЦП</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Session</source>
        <translation>Сесія</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Seat</source>
        <translation>Робоче місце</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Process</source>
        <translation>Процес</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="104"/>
        <source>Processes (%1)</source>
        <translation>Процеси (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="198"/>
        <source>Refresh (%1)</source>
        <translation>Оновлення (%1)</translation>
    </message>
</context>
<context>
    <name>ResourcesPage</name>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="26"/>
        <source>CPU History</source>
        <translation>Використання ЦП</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="29"/>
        <source>Memory History</source>
        <translation>Використання пам'яті і підкачування</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="32"/>
        <source>Network History</source>
        <translation>Використання мережі</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="76"/>
        <source>Download %1/s Total: %2</source>
        <translation>Отримано %1/с Всього: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="81"/>
        <source>Upload %1/s  Total: %2</source>
        <translation>Надіслано %1/с Всього: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="122"/>
        <source>Swap %1 (%2%) %3</source>
        <translation>Підкачка %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="131"/>
        <source>Memory %1 (%2%) %3</source>
        <translation>Пам'ять %1 (%2%) %3</translation>
    </message>
</context>
<context>
    <name>ServicesPage</name>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="79"/>
        <source>System Services</source>
        <translation>Системні служби</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="123"/>
        <source>Startup at boot ?</source>
        <translation>Запускати при завантаженні?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="176"/>
        <source>Running Now ?</source>
        <translation>Запущено зараз?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="246"/>
        <source>Not Found System Service</source>
        <translation>Системні служби не знайдені</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="50"/>
        <source>System Services (%1)</source>
        <translation>Системні служби (%1)</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="54"/>
        <source>Language</source>
        <translation>Мова</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="71"/>
        <source>Theme</source>
        <translation>Тема</translation>
    </message>
</context>
<context>
    <name>StartupApp</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="23"/>
        <source>Delete</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="24"/>
        <source>Edit</source>
        <translation>Змінити</translation>
    </message>
</context>
<context>
    <name>StartupAppEdit</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="20"/>
        <source>Startup App</source>
        <translation>Запуск програми</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="50"/>
        <source>Save</source>
        <translation>Зберегти</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="60"/>
        <source>Fields cannot be left blank. </source>
        <translation>Необхідно заповнити поля. </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="67"/>
        <source>App Comment</source>
        <translation>Опис</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="74"/>
        <source>App Name</source>
        <translation>Ім'я</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="81"/>
        <source>Command</source>
        <translation>Команда</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="88"/>
        <source>Application</source>
        <translation>Програма</translation>
    </message>
</context>
<context>
    <name>StartupAppsPage</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="95"/>
        <source>Add Startup App</source>
        <translation>Додати</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="112"/>
        <source>System Startup Applications</source>
        <translation>Програми які автоматично запускаються</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="192"/>
        <source>Not Found Startup Apps</source>
        <translation>Не знайдено програми які автоматично запускаються</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.cpp" line="79"/>
        <source>System Startup Applications (%1)</source>
        <translation>Програми які автоматично запускаються (%1)</translation>
    </message>
</context>
<context>
    <name>SystemCleanerPage</name>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="63"/>
        <source>Crash Reports</source>
        <translation>Звіти про помилки</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="168"/>
        <source>Application Logs</source>
        <translation>Журнали програми</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="206"/>
        <source>Application Caches</source>
        <translation>Кеші програми</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="327"/>
        <source>Trash</source>
        <translation>Смітник</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="365"/>
        <source>Package Caches</source>
        <translation>Завантажені пакети</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="473"/>
        <source> Back</source>
        <translation> Назад</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>File Name</source>
        <translation>Ім'я файлу</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="285"/>
        <source>%1 size files cleaned.</source>
        <translation>Звільнено %1.</translation>
    </message>
</context>
<context>
    <name>UninstallerPage</name>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="132"/>
        <source>Uninstall Selected</source>
        <translation>Видалити вибрані</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="178"/>
        <source>Not Found Installed Packages</source>
        <translation>Встановлені пакети не знайдені</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="228"/>
        <source>System Installed Packages</source>
        <translation>Системні пакети</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="271"/>
        <source>Search...</source>
        <translation>Пошук...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstaller_page.cpp" line="65"/>
        <source>System Installed Packages (%1)</source>
        <translation>Системні пакети (%1)</translation>
    </message>
</context>
</TS>
