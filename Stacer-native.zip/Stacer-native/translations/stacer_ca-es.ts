<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca_ES">
<context>
    <name>App</name>
    <message>
        <location filename="../stacer/app.cpp" line="80"/>
        <source>Dashboard</source>
        <translation>Panell de control</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="85"/>
        <source>System Cleaner</source>
        <translation>Netejador del sistema</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="90"/>
        <source>System Startup Apps</source>
        <translation>Aplicacions d'inici del sistema</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="95"/>
        <source>System Services</source>
        <translation>Serveis del sistema</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="100"/>
        <source>Uninstaller</source>
        <translation>Desinstal·lador</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="105"/>
        <source>Resources</source>
        <translation>Recursos</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="110"/>
        <source>Processes</source>
        <translation>Processos</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="115"/>
        <source>Settings</source>
        <translation>Configuració</translation>
    </message>
</context>
<context>
    <name>DashboardPage</name>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="153"/>
        <source>SYSTEM INFO</source>
        <translation>INFORMACIÓ DEL SISTEMA</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="240"/>
        <source>There are update currently available.</source>
        <translation>Hi ha actualitzacions disponibles.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="253"/>
        <source>Download</source>
        <translation>Baixa</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="18"/>
        <source>CPU</source>
        <translation>CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="19"/>
        <source>MEMORY</source>
        <translation>MEMÒRIA</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="20"/>
        <source>DISK</source>
        <translation>DISC</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="21"/>
        <source>DOWNLOAD</source>
        <translation>BAIXADA</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="22"/>
        <source>UPLOAD</source>
        <translation>PUJADA</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="107"/>
        <source>Hostname: %1</source>
        <translation>Nom de l'amfitrió: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="108"/>
        <source>Platform: %1</source>
        <translation>Platforma: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="109"/>
        <source>Distribution: %1</source>
        <translation>Distribució: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="110"/>
        <source>Kernel Release: %1</source>
        <translation>Versió del nucli: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="111"/>
        <source>CPU Model: %1</source>
        <translation>Model de la CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="112"/>
        <source>CPU Speed: %1</source>
        <translation>Velocitat de la CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="113"/>
        <source>CPU Core: %1</source>
        <translation>Nuclis de la CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="182"/>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="186"/>
        <source>Total: %1</source>
        <translation>Total: %1</translation>
    </message>
</context>
<context>
    <name>ProcessesPage</name>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="55"/>
        <source>Processes</source>
        <translation>Processos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="68"/>
        <source>All Processes</source>
        <translation>Tots els processos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="88"/>
        <source>Search...</source>
        <translation>Cerca...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="206"/>
        <source>End Process</source>
        <translation>Finalitza el procés</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>User</source>
        <translation>Usuari</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Resident Memory</source>
        <translation>Memòria resident</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>%Memory</source>
        <translation>%Memòria</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Virtual Memory</source>
        <translation>Memòria virtual</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Start Time</source>
        <translation>Hora d'inici</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>State</source>
        <translation>Estat</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Group</source>
        <translation>Grup</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Nice</source>
        <translation>Bonic</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>CPU Time</source>
        <translation>Temps de la CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Session</source>
        <translation>Sessió</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Seat</source>
        <translation>Seient</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Process</source>
        <translation>Procés</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="104"/>
        <source>Processes (%1)</source>
        <translation>Processos (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="198"/>
        <source>Refresh (%1)</source>
        <translation>Refresca (%1)</translation>
    </message>
</context>
<context>
    <name>ResourcesPage</name>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="26"/>
        <source>CPU History</source>
        <translation>Històric de la CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="29"/>
        <source>Memory History</source>
        <translation>Històric de la memòria</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="32"/>
        <source>Network History</source>
        <translation>Històric de la xarxa</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="76"/>
        <source>Download %1/s Total: %2</source>
        <translation>Baixa %1/s Total: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="81"/>
        <source>Upload %1/s  Total: %2</source>
        <translation>Puja %1/s  Total: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="122"/>
        <source>Swap %1 (%2%) %3</source>
        <translation>Intercanvi %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="131"/>
        <source>Memory %1 (%2%) %3</source>
        <translation>Memòria %1 (%2%) %3</translation>
    </message>
</context>
<context>
    <name>ServicesPage</name>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="79"/>
        <source>System Services</source>
        <translation>Serveis del sistema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="123"/>
        <source>Startup at boot ?</source>
        <translation>Carrega a l'inici?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="176"/>
        <source>Running Now ?</source>
        <translation>S'està executant ara?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="246"/>
        <source>Not Found System Service</source>
        <translation>Servei del sistema no trobat</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="50"/>
        <source>System Services (%1)</source>
        <translation>Serveis del sistema (%1)</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="54"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="71"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
</context>
<context>
    <name>StartupApp</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="23"/>
        <source>Delete</source>
        <translation>Esborra</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="24"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
</context>
<context>
    <name>StartupAppEdit</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="20"/>
        <source>Startup App</source>
        <translation>Aplicació d'inici</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="50"/>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="60"/>
        <source>Fields cannot be left blank.</source>
        <translation>Els camps no es poden deixar en blanc.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="67"/>
        <source>App Comment</source>
        <translation>Comentari de l'aplicació</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="74"/>
        <source>App Name</source>
        <translation>Nom de l'aplicació</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="81"/>
        <source>Command</source>
        <translation>Ordre</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="88"/>
        <source>Application</source>
        <translation>Aplicació</translation>
    </message>
</context>
<context>
    <name>StartupAppsPage</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="192"/>
        <source>Not Found Startup Apps</source>
        <translation>No s'han trobat aplicacions d'inici</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="112"/>
        <source>System Startup Applications</source>
        <translation>Aplicacions d'inici del sistema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="95"/>
        <source>Add Startup App</source>
        <translation>Afegeix una aplicació d'inici</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.cpp" line="79"/>
        <source>System Startup Applications (%1)</source>
        <translation>Aplicacions d'inici del sistema (%1)</translation>
    </message>
</context>
<context>
    <name>SystemCleanerPage</name>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="63"/>
        <source>Crash Reports</source>
        <translation>Informes de fallida</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="168"/>
        <source>Application Logs</source>
        <translation>Registres d'aplicacions</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="206"/>
        <source>Application Caches</source>
        <translation>Memòria cau d'aplicacions</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="327"/>
        <source>Trash</source>
        <translation>Paperera</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="365"/>
        <source>Package Caches</source>
        <translation>Memòria cau dels paquets</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="473"/>
        <source> Back</source>
        <translation>Enrere</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>File Name</source>
        <translation>Nom del fitxer</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="285"/>
        <source>%1 size files cleaned.</source>
        <translation>S'ha netejat fitxers de mida %1</translation>
    </message>
</context>
<context>
    <name>UninstallerPage</name>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="228"/>
        <source>System Installed Packages</source>
        <translation>Paquets instal·lats del sistema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="271"/>
        <source>Search...</source>
        <translation>Cerca...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="178"/>
        <source>Not Found Installed Packages</source>
        <translation>No s'han trobat paquets instal·lats</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="132"/>
        <source>Uninstall Selected</source>
        <translation>Desinstal·la els seleccionats</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstaller_page.cpp" line="65"/>
        <source>System Installed Packages (%1)</source>
        <translation>Paquets instal·lats del sistema (%1)</translation>
    </message>
</context>
</TS>
