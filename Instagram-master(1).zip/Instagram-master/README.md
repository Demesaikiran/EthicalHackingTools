# Usage
python instagram.py  [Username]  [wordlist]

`python instagram.py username103 pass.lst`

## Requirements
[mechanize](https://pypi.python.org/pypi/mechanize/) install with: `pip install mechanize`

[requests](https://pypi.python.org/pypi/requests/2.18.4) install with: `pip install requests`

[Tor](https://www.torproject.org/docs/debian) install with: `sudo apt-get install tor`
