don't delete configuration file and some tools 
