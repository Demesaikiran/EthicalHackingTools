git clone https://github.com/Manisso/fsociety.git
sudo chmod +x fsociety/install.sh
bash fsociety/install.sh
