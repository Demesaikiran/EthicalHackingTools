[![Version](https://img.shields.io/badge/Devploit-v2.3-brightgreen.svg?maxAge=259200)]()
[![Python 2.x](https://img.shields.io/badge/python-2.x-blue.svg)]()
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Ubuntu,Kali,Mint,Parrot-blue,Windows,Android.svg)]()
[![AUR](https://img.shields.io/aur/license/yaourt.svg)]()
## ★ Devploit . version 2.3

   Author: Joker-Security [ dev-labs ]

## ★ Description:

Devploit is a simple python script to Information Gathering 

## ★ Download:

● git clone https://github.com/joker25000/Devploit

## ★ How to use:

cd Devploit

chmod +x install

./install

Run in Terminal 

Devploit

(To run in Android you do not install file Run direct python2 Devploit)
## ★ Properties :

● DNS Lookup 
● Whois Lookup
● GeoIP Lookup
● Subnet Lookup
● Port Scanner
● Extract Links 
● Zone Transfer
● HTTP Header
● Host Finder
● IP-Locator
● Traceroute
● Host DNS Finder
● Revrse IP Lookup
● Collection Email
● Install & Update
● About Me 
● Exit

## ★ Screenshot:

<img src="https://i.imgur.com/k0XG34B.png" width="23%"></img> <img src="https://i.imgur.com/vvgOEw1.png" width="23%"></img> <img src="https://i.imgur.com/B3rOz5B.png" width="23%"></img> 


## ★ video tutorial:

[![ Devploit - Information Gathering Tool (Version 2.3) ](https://i.ytimg.com/vi/jJ9cZ-IcLg4/hqdefault.jpg)](https://www.youtube.com/watch?v=jJ9cZ-IcLg4)

## ★ About:

● YOUTUBE : https://www.youtube.com/c/Professionalhacker25

● Twitter : https://twitter.com/SecurityJoker

● FACE Pg : https://facebook.com/kali.linux.pentesting.tutorials

● Tested On : Windows / Linux / Android Phone (Termux No root)

