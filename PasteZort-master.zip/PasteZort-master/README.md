# PasteZort
Pastejacking - PasteZort

# Uso:

./PasteZort.py


